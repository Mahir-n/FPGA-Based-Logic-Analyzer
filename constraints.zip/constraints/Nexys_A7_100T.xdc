## =============================================================================
##  BOARD 1 — Logic Analyzer (MODIFIED for PMOD probe input)
##  Nexys A7-100T XDC
##  Top module: system_top
##
##  Probe inputs come from PMOD JB (connected to Board 2's PMOD JA).
## =============================================================================

## ─── Clock ──────────────────────────────────────────────────────────────────
set_property -dict { PACKAGE_PIN E3   IOSTANDARD LVCMOS33 } [get_ports { CLK100MHZ }]
create_clock -add -name sys_clk_pin -period 10.00 -waveform {0 5} [get_ports { CLK100MHZ }]

## ─── Reset (BTNC) ───────────────────────────────────────────────────────────
set_property -dict { PACKAGE_PIN N17  IOSTANDARD LVCMOS33 } [get_ports { BTNC }]

## ─── Free-Run Switch (SW[8]) ────────────────────────────────────────────────
set_property -dict { PACKAGE_PIN T8   IOSTANDARD LVCMOS18 } [get_ports { SW_FREE }]

## ─── PMOD JB — Probe Inputs (from Board 2 Signal Generator) ─────────────────
## Top row (pins 1-4)
set_property -dict { PACKAGE_PIN D14  IOSTANDARD LVCMOS33 } [get_ports { JB[0] }]
set_property -dict { PACKAGE_PIN F16  IOSTANDARD LVCMOS33 } [get_ports { JB[1] }]
set_property -dict { PACKAGE_PIN G16  IOSTANDARD LVCMOS33 } [get_ports { JB[2] }]
set_property -dict { PACKAGE_PIN H14  IOSTANDARD LVCMOS33 } [get_ports { JB[3] }]

## Bottom row (pins 7-10)
set_property -dict { PACKAGE_PIN E16  IOSTANDARD LVCMOS33 } [get_ports { JB[4] }]
set_property -dict { PACKAGE_PIN F13  IOSTANDARD LVCMOS33 } [get_ports { JB[5] }]
set_property -dict { PACKAGE_PIN G13  IOSTANDARD LVCMOS33 } [get_ports { JB[6] }]
set_property -dict { PACKAGE_PIN H16  IOSTANDARD LVCMOS33 } [get_ports { JB[7] }]

## ─── UART ───────────────────────────────────────────────────────────────────
set_property -dict { PACKAGE_PIN C4   IOSTANDARD LVCMOS33 } [get_ports { UART_RX }]
set_property -dict { PACKAGE_PIN D4   IOSTANDARD LVCMOS33 } [get_ports { UART_TX }]

## ─── Configuration ──────────────────────────────────────────────────────────
set_property CFGBVS VCCO         [current_design]
set_property CONFIG_VOLTAGE 3.3  [current_design]
