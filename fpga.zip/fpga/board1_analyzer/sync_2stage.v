`timescale 1ns / 1ps
// =============================================================================
//  sync_2stage.v
//  Generic 2-stage synchronizer to prevent metastability.
//  Parameterized width so it can be used for both the 8-bit
//  signal bus and the single-bit UART RX line.
//
//  The (* ASYNC_REG = "TRUE" *) attribute on both registers tells Vivado:
//    1. Place both FFs in the same slice (or adjacent slices) to minimise
//       routing delay between stage 1 and stage 2.
//    2. Maximise the metastability settling time available between the two
//       flip-flop stages — without this, Vivado may route them far apart,
//       leaving insufficient settling time and allowing metastability to
//       propagate into the design logic.
//    3. Disable optimisations (merging, retiming, replication) that would
//       break the synchronizer chain.
//  Without ASYNC_REG the HDL logic is structurally correct but Vivado has
//  no knowledge that these FFs are a synchronizer — placement is arbitrary
//  and worst-case routing can cause real metastability failures on hardware.
//
//  Usage:
//    sync_2stage #(.WIDTH(8)) u_sig_sync (
//        .clk(clk), .d(signals), .q(synced_signals)
//    );
// =============================================================================
module sync_2stage #(
    parameter WIDTH = 1
)(
    input  wire             clk,
    input  wire [WIDTH-1:0] d,
    output wire [WIDTH-1:0] q
);

// [BUG 3 FIX] ASYNC_REG on both registers — tells Vivado to co-locate these
// FFs in the same slice and protect them from optimisation that would break
// the metastability resolution chain.
(* ASYNC_REG = "TRUE" *) reg [WIDTH-1:0] meta;
(* ASYNC_REG = "TRUE" *) reg [WIDTH-1:0] q_reg;

always @(posedge clk) begin
    meta  <= d;      // stage 1 — may be metastable
    q_reg <= meta;   // stage 2 — resolved
end

// Drive output port from the protected register
assign q = q_reg;

endmodule
