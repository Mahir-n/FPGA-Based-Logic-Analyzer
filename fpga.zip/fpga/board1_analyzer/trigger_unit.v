`timescale 1ns / 1ps
// =============================================================================
//  trigger_unit.v
//  User-configurable trigger engine.
//
//  Trigger is evaluated only on `sample_en` boundaries so the trigger
//  event is always aligned to an actual sample — no sub-sample jitter.
//
//  Configuration (set by cmd_decoder via UART):
//    trig_ch   [2:0] : which channel to watch (0–7)
//    trig_edge [0]   : 0 = rising edge,  1 = falling edge
//
//  Modes:
//    free_run = 1 : triggered is always high (continuous capture, no wait)
//    free_run = 0 : triggered goes high on the configured edge event,
//                   resets after send_done so each capture is a fresh trigger
//
//  Output:
//    triggered : high while capture should be running
//
//  Spurious-trigger protection:
//    prev_sample is seeded from the real signal level on the first sample_en
//    after reset, preventing a false edge from prev=0x00 vs actual level.
//
//    Additionally, if trig_ch changes while the unit is in the armed (idle)
//    state, first_sample is re-asserted so that prev_sample is reseeded from
//    the new channel's actual level before any edge comparison is made.
//    Without this, prev_sample[new_ch] contains an arbitrary historical value
//    that can immediately satisfy trig_condition on the very next sample_en,
//    producing a false capture at fast sample rates (10 MHz+).
//
//    trig_edge changes do NOT require a reseed — prev_sample is still a valid
//    snapshot of all channel levels; only the comparison direction changes.
// =============================================================================
module trigger_unit (
    input  wire       clk,
    input  wire       reset,

    // sampling
    input  wire       sample_en,    // from sample_divider
    input  wire [7:0] sampled,      // current sample (all 8 channels)

    // trigger configuration (from cmd_decoder)
    input  wire [2:0] trig_ch,      // channel select 0–7
    input  wire       trig_edge,    // 0=rising, 1=falling

    // control
    input  wire       free_run,     // free-run switch
    input  wire       send_done,    // from tx_fsm — capture was sent

    // output
    output reg        triggered
);

// ── Previous sample register + first-sample guard ────────────────────────────
reg [7:0] prev_sample;
reg       first_sample;   // high after reset (or trig_ch change) until
                          // the first sample_en reseeds prev_sample

// ── Trigger-channel change detector ──────────────────────────────────────────
// Compares trig_ch this cycle against last cycle's value.  When a change is
// detected, first_sample is re-armed so the comparator waits one more
// sample_en before evaluating trig_condition on the new channel.
// Registered to avoid combinatorial loops; one-cycle reaction delay is fine
// because the channel change arrives via UART (millions of cycles apart).
reg [2:0] trig_ch_prev;
wire      trig_ch_changed = (trig_ch != trig_ch_prev);

// ── Trigger condition ─────────────────────────────────────────────────────────
wire cur_bit  = sampled[trig_ch];
wire prev_bit = prev_sample[trig_ch];

// Rising edge:  prev=0, cur=1
// Falling edge: prev=1, cur=0
wire trig_condition = trig_edge ? (prev_bit && !cur_bit)
                                : (!prev_bit && cur_bit);

// ── FSM ───────────────────────────────────────────────────────────────────────
always @(posedge clk or posedge reset) begin
    if (reset) begin
        prev_sample  <= 8'h00;
        triggered    <= 1'b0;
        first_sample <= 1'b1;   // arm the guard
        trig_ch_prev <= 3'd0;
    end else begin

        // ── Track trig_ch and re-arm guard on channel change ──────────────
        trig_ch_prev <= trig_ch;

        if (trig_ch_changed) begin
            // New channel selected — force a prev_sample reseed on the next
            // sample_en so trig_condition never sees a stale prev_bit value.
            // Using else-if below means the reseed happens on the sample_en
            // that follows the channel-change clock, not the same cycle.
            first_sample <= 1'b1;

        end else if (sample_en) begin
            if (first_sample) begin
                // Seed prev_sample from the actual signal state so the
                // comparator never sees a spurious edge on the first check.
                prev_sample  <= sampled;
                first_sample <= 1'b0;
            end else begin
                prev_sample <= sampled;
            end
        end

        // ── Trigger state machine ─────────────────────────────────────────
        // trig_condition is only evaluated after first_sample has been
        // cleared (channel history is valid), so no false trigger can fire.
        if (triggered && send_done) begin
            // Capture sent — re-arm according to mode.
            triggered <= free_run ? 1'b1 : 1'b0;

        end else if (!triggered && !first_sample && !trig_ch_changed) begin
            if (free_run)
                triggered <= 1'b1;
            else if (sample_en && trig_condition)
                triggered <= 1'b1;
        end

    end
end

endmodule
