`timescale 1ns / 1ps
// =============================================================================
//  capture_mem.v
//  1024 x 8-bit capture memory inferred as Block RAM by Vivado.
//
//  Write port:
//    Controlled by trigger + sample_en.
//    Writes one byte per sample_en pulse while triggered and not frozen.
//    Sets freeze when DEPTH samples have been written (all mem[0..DEPTH-1]
//    are valid).
//
//  Read port:
//    SYNCHRONOUS registered read - required for Vivado to infer true BRAM.
//    An asynchronous (combinatorial) read forces Vivado to fall back to
//    distributed LUT RAM regardless of the ram_style attribute.
//    tx_fsm.v already has an S_LOAD state that waits one cycle after
//    presenting rd_addr, so the one-cycle read latency is fully absorbed
//    with no change to the FSM.
//
//  BRAM inference note:
//    The memory write (mem[wr_ptr] <= sampled) MUST be in its own
//    always @(posedge clk) block WITHOUT async reset in the sensitivity
//    list. Vivado cannot map a memory array to BRAM if the write is
//    inside an always block with async reset, because physical BRAM
//    primitives have no async reset on the write port. Mixing the
//    memory write with control registers (wr_ptr, freeze) that need
//    async reset forces Vivado to fall back to distributed LUT-RAM.
//
//  Reset / re-arm:
//    send_done from tx_fsm clears freeze and resets wr_ptr,
//    making the memory ready for the next trigger.
//
//  wr_ptr behaviour at full:
//    When the last sample is written (wr_ptr == DEPTH-1), freeze is asserted
//    and wr_ptr is intentionally left at DEPTH-1 rather than incremented to
//    DEPTH.  The freeze flag is the only downstream status signal; wr_ptr
//    is not exposed outside this module and its stuck value has no functional
//    consequence.  send_done resets it to 0 regardless.
// =============================================================================
module capture_mem #(
    parameter DEPTH      = 1024,
    parameter ADDR_WIDTH = $clog2(DEPTH)    // 10 bits
)(
    input  wire                  clk,
    input  wire                  reset,

    // write side
    input  wire                  sample_en,
    input  wire                  triggered,
    input  wire [7:0]            sampled,
    input  wire                  send_done,  // re-arm signal from tx_fsm

    // read side (driven by tx_fsm)
    input  wire [ADDR_WIDTH-1:0] rd_addr,
    output reg  [7:0]            rd_data,    // registered - 1 cycle latency

    // status
    output reg                   freeze      // high when DEPTH samples captured
);

// ── Memory array - Vivado infers BRAM only with a registered read port ────────
(* ram_style = "block" *)
reg [7:0] mem [0:DEPTH-1];

reg [ADDR_WIDTH-1:0] wr_ptr;

// ── Synchronous read port ─────────────────────────────────────────────────────
// Must be registered (not combinatorial) for Vivado to infer Block RAM.
// The one-cycle read latency is absorbed by tx_fsm's S_ADDR state.
always @(posedge clk)
    rd_data <= mem[rd_addr];

// ── Memory write port (separate block, NO async reset) ────────────────────────
// This block MUST NOT have async reset in the sensitivity list.
// Vivado BRAM inference requires that the memory write exists in a
// pure synchronous always @(posedge clk) block.
always @(posedge clk) begin
    if (triggered && !freeze && sample_en) begin
        mem[wr_ptr] <= sampled;
    end
end

// ── Write pointer + freeze control (async reset allowed here) ─────────────────
// Only wr_ptr and freeze are in this block - NOT the mem[] write.
always @(posedge clk or posedge reset) begin
    if (reset) begin
        wr_ptr <= 0;
        freeze <= 1'b0;
    end else begin

        if (send_done) begin
            // TX FSM finished - re-arm for next trigger.
            // Clears freeze and resets wr_ptr regardless of its current value
            // (including the intentional stuck-at DEPTH-1 case; see header).
            freeze <= 1'b0;
            wr_ptr <= 0;

        end else if (triggered && !freeze && sample_en) begin
            if (wr_ptr == DEPTH - 1) begin
                // Buffer full - assert freeze and stop writing.
                // wr_ptr is intentionally left at DEPTH-1 here (not
                // incremented to DEPTH) because freeze is the only signal
                // used downstream; wr_ptr is not observed externally.
                freeze <= 1'b1;
            end else
                wr_ptr <= wr_ptr + 1;
        end

    end
end

endmodule
