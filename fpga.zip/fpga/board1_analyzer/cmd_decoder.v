`timescale 1ns / 1ps
// =============================================================================
//  cmd_decoder.v
//  UART Command Decoder — interprets received bytes and updates
//  sample rate divider and trigger configuration registers.
//
//  ── PROTOCOL ──────────────────────────────────────────────────────────────
//
//  RATE COMMANDS  (byte range 0x01 – 0x12):
//    0x01 → 100 MHz  (div =           1)
//    0x02 →  50 MHz  (div =           2)
//    0x03 →  25 MHz  (div =           4)
//    0x04 →  10 MHz  (div =          10)
//    0x05 →   5 MHz  (div =          20)
//    0x06 →   1 MHz  (div =         100)
//    0x07 → 500 KHz  (div =         200)
//    0x08 → 100 KHz  (div =       1_000)
//    0x09 →  50 KHz  (div =       2_000)
//    0x0A →  10 KHz  (div =      10_000)
//    0x0B →   5 KHz  (div =      20_000)
//    0x0C →   1 KHz  (div =     100_000)
//    0x0D → 500 Hz   (div =     200_000)
//    0x0E → 100 Hz   (div =   1_000_000)
//    0x0F →  50 Hz   (div =   2_000_000)
//    0x10 →  10 Hz   (div =  10_000_000)
//    0x11 →   5 Hz   (div =  20_000_000)
//    0x12 →   1 Hz   (div = 100_000_000)
//
//  TRIGGER COMMANDS  (byte range 0x20 – 0x2F):
//    Upper nibble = 0x2  →  trigger config command
//    Bit  [3]     = edge select  : 0 = rising,  1 = falling
//    Bits [2:0]   = channel      : 0–7  (CH0–CH7)
//
//    Examples:
//      0x20 = rising  edge on CH0    (0010_0000)
//      0x21 = rising  edge on CH1    (0010_0001)
//      0x27 = rising  edge on CH7    (0010_0111)
//      0x28 = falling edge on CH0    (0010_1000)
//      0x2F = falling edge on CH7    (0010_1111)
//
//  Unrecognised bytes are silently ignored.
// =============================================================================
module cmd_decoder #(
    parameter DIV_WIDTH = 27
)(
    input  wire                  clk,
    input  wire                  reset,

    // from uart_rx
    input  wire                  rx_valid,
    input  wire [7:0]            rx_data,

    // outputs to sample_divider
    output reg  [DIV_WIDTH-1:0]  rate_div,

    // outputs to trigger_unit
    output reg  [2:0]            trig_ch,
    output reg                   trig_edge   // 0=rising, 1=falling
);

always @(posedge clk or posedge reset) begin
    if (reset) begin
        rate_div  <= 27'd1;     // default: 100 MHz
        trig_ch   <= 3'd0;      // default: CH0
        trig_edge <= 1'b0;      // default: rising edge
    end else if (rx_valid) begin

        // ── Trigger config command: upper nibble = 0x2 ───────────────────
        if (rx_data[7:4] == 4'h2) begin
            trig_ch   <= rx_data[2:0];  // bits[2:0] = channel select
            trig_edge <= rx_data[3];    // bit[3]    = edge select
        end

        // ── Sample rate command: 0x01 – 0x12 ─────────────────────────────
        else begin
            case (rx_data)
                8'h01: rate_div <= 27'd1;
                8'h02: rate_div <= 27'd2;
                8'h03: rate_div <= 27'd4;
                8'h04: rate_div <= 27'd10;
                8'h05: rate_div <= 27'd20;
                8'h06: rate_div <= 27'd100;
                8'h07: rate_div <= 27'd200;
                8'h08: rate_div <= 27'd1_000;
                8'h09: rate_div <= 27'd2_000;
                8'h0A: rate_div <= 27'd10_000;
                8'h0B: rate_div <= 27'd20_000;
                8'h0C: rate_div <= 27'd100_000;
                8'h0D: rate_div <= 27'd200_000;
                8'h0E: rate_div <= 27'd1_000_000;
                8'h0F: rate_div <= 27'd2_000_000;
                8'h10: rate_div <= 27'd10_000_000;
                8'h11: rate_div <= 27'd20_000_000;
                8'h12: rate_div <= 27'd100_000_000;
                default: ;  // unknown byte — ignore
            endcase
        end

    end
end

endmodule
