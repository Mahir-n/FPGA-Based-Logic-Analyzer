`timescale 1ns / 1ps
// =============================================================================
//  tx_fsm.v
//  Sender FSM — reads capture_mem and streams all bytes over UART TX.
//
//  Triggered by `freeze` going high (capture_mem is full).
//  Sends a 2-byte sync header (0xAA, 0x55) before the 1024 data bytes
//  so the Python receiver can always find the frame boundary — even if it
//  connects mid-stream or loses sync after a glitch.
//
//  Full transmission per capture:
//    [0xAA] [0x55] [mem[0]] [mem[1]] ... [mem[1023]]   = 1026 bytes total
//
//  States:
//    S_IDLE   : wait for freeze
//    S_HDR1   : send header byte 1 (0xAA)
//    S_WAIT_H : wait for 0xAA to finish (saw_busy handshake)
//    S_HDR2   : send header byte 2 (0x55), then immediately go to S_ADDR
//    S_ADDR   : present rd_addr — wait 1 cycle for BRAM registered output
//    S_LOAD   : latch rd_data into tx_data (BRAM data now valid)
//    S_SEND   : wait for uart_tx free, fire tx_start
//    S_WAIT   : wait for last byte stop bit to finish (saw_busy handshake)
//
//  S_HDR1 vs S_HDR2 asymmetry (intentional):
//    S_HDR1 uses its own S_WAIT_H state to wait for 0xAA to fully transmit.
//    S_HDR2 does not have a matching wait state — after firing tx_start for
//    0x55 it immediately transitions to S_ADDR.  This is safe because S_SEND
//    always checks !tx_busy before firing the next tx_start, and 0x55 will
//    have finished transmitting long before the BRAM pipeline (S_ADDR+S_LOAD)
//    completes and S_SEND is first reached.  S_HDR1 needs its own wait state
//    because S_HDR2 also checks !tx_busy at the top — without S_WAIT_H the
//    FSM could re-enter S_HDR1 and attempt to re-fire 0xAA while 0xAA is
//    still transmitting.
//
//  S_IDLE guard — `freeze && !send_done`:
//    send_done is a single-cycle pulse asserted in S_WAIT on the same clock
//    that the FSM returns to S_IDLE.  At that moment capture_mem has not yet
//    cleared freeze (it does so on the next posedge in response to send_done).
//    Without !send_done, the FSM would see freeze=1, send_done=1 and
//    immediately re-enter S_HDR1, starting a second transmission of stale
//    data before the capture buffer has been re-armed.
// =============================================================================
module tx_fsm #(
    parameter DEPTH      = 1024,
    parameter ADDR_WIDTH = $clog2(DEPTH)
)(
    input  wire                  clk,
    input  wire                  reset,

    // memory interface
    input  wire                  freeze,
    output reg  [ADDR_WIDTH-1:0] rd_addr,
    input  wire [7:0]            rd_data,

    // uart_tx interface
    input  wire                  tx_busy,
    output reg                   tx_start,
    output reg  [7:0]            tx_data,

    // control output
    output reg                   send_done   // single-cycle pulse
);

// ── State encoding ────────────────────────────────────────────────────────────
localparam S_IDLE    = 4'd0;
localparam S_HDR1    = 4'd1;   // send 0xAA
localparam S_WAIT_H  = 4'd2;   // wait for 0xAA to finish (saw_busy handshake)
localparam S_HDR2    = 4'd3;   // send 0x55
localparam S_ADDR    = 4'd4;   // wait 1 cycle for BRAM registered output
localparam S_LOAD    = 4'd5;   // latch rd_data into tx_data
localparam S_SEND    = 4'd6;   // fire tx_start
localparam S_WAIT    = 4'd7;   // wait for stop bit to finish

reg [3:0] state;
reg       saw_busy;

// ── FSM ───────────────────────────────────────────────────────────────────────
always @(posedge clk or posedge reset) begin
    if (reset) begin
        state     <= S_IDLE;
        rd_addr   <= 0;
        tx_start  <= 1'b0;
        tx_data   <= 8'h00;
        send_done <= 1'b0;
        saw_busy  <= 1'b0;
    end else begin
        tx_start  <= 1'b0;
        send_done <= 1'b0;

        case (state)

            // ── Wait for capture buffer to fill ──────────────────────────
            // !send_done guard: send_done pulses for exactly one cycle as we
            // return here from S_WAIT.  At that same moment freeze is still
            // high (capture_mem clears it on the next posedge).  Without the
            // guard the FSM would immediately loop back to S_HDR1 and start
            // re-transmitting stale data — see header comment for full detail.
            S_IDLE: begin
                if (freeze && !send_done)
                    state <= S_HDR1;
            end

            // ── Send sync header byte 1: 0xAA ─────────────────────────────
            // Python scans for 0xAA 0x55 to find frame start.
            S_HDR1: begin
                if (!tx_busy) begin
                    tx_data  <= 8'hAA;
                    tx_start <= 1'b1;
                    saw_busy <= 1'b0;
                    state    <= S_WAIT_H;
                end
            end

            // ── Wait for header byte 1 to finish transmitting ─────────────
            // S_HDR1 needs this explicit wait because S_HDR2 also checks
            // !tx_busy at its top.  Without S_WAIT_H the FSM could see
            // !tx_busy before uart_tx has asserted tx_busy and loop back,
            // firing a second 0xAA — see header comment for full detail.
            S_WAIT_H: begin
                if (tx_busy)
                    saw_busy <= 1'b1;
                if (saw_busy && !tx_busy)
                    state <= S_HDR2;
            end

            // ── Send sync header byte 2: 0x55 ─────────────────────────────
            // No matching wait state needed here — see header comment
            // (S_HDR1 vs S_HDR2 asymmetry) for the full explanation.
            // rd_addr is reset to 0 here so the BRAM pipeline starts at
            // address 0 in parallel while 0x55 is still transmitting.
            S_HDR2: begin
                if (!tx_busy) begin
                    tx_data  <= 8'h55;
                    tx_start <= 1'b1;
                    rd_addr  <= 0;
                    state    <= S_ADDR;
                end
            end

            // ── Address setup: wait 1 cycle for BRAM output to settle ─────
            // capture_mem uses a synchronous (registered) read port to allow
            // Vivado to infer true Block RAM.  rd_data is valid one cycle
            // after rd_addr is presented — this state absorbs that latency.
            S_ADDR: begin
                state <= S_LOAD;
            end

            // ── Latch stable BRAM output into tx_data ─────────────────────
            S_LOAD: begin
                tx_data <= rd_data;
                state   <= S_SEND;
            end

            // ── Fire tx_start when UART TX is free ────────────────────────
            S_SEND: begin
                if (!tx_busy) begin
                    tx_start <= 1'b1;

                    if (rd_addr == DEPTH - 1) begin
                        // Last byte — go wait for the stop-bit guard to expire.
                        saw_busy <= 1'b0;
                        state    <= S_WAIT;
                    end else begin
                        // Increment address and fetch the next byte from BRAM.
                        rd_addr <= rd_addr + 1;
                        state   <= S_ADDR;
                    end
                end
            end

            // ── Wait for last byte stop bit to fully transmit ─────────────
            // The saw_busy handshake (wait for tx_busy to go high then fall)
            // guarantees we observe a complete tx_busy pulse and do not
            // mistake the pre-transmission !tx_busy for "done".
            S_WAIT: begin
                if (tx_busy)
                    saw_busy <= 1'b1;

                if (saw_busy && !tx_busy) begin
                    send_done <= 1'b1;
                    state     <= S_IDLE;
                end
            end

            default: state <= S_IDLE;
        endcase
    end
end

endmodule
