`timescale 1ns / 1ps
// =============================================================================
//  sample_divider.v
//  Programmable sample-rate divider.
//
//  Generates a single-cycle pulse `sample_en` every `rate_div` clock cycles.
//  All downstream logic (trigger, capture memory) is gated by this pulse,
//  so the time axis always represents exactly DEPTH samples at the chosen rate.
//
//  rate_div = 1        → sample every clock  = 100 MHz
//  rate_div = 10       → sample every 10     =  10 MHz
//  rate_div = 100      → sample every 100    =   1 MHz
//  ... etc (set by cmd_decoder via UART command)
// =============================================================================
module sample_divider #(
    parameter DIV_WIDTH = 27    // ceil(log2(100_000_000)) = 27
)(
    input  wire                  clk,
    input  wire                  reset,
    input  wire [DIV_WIDTH-1:0]  rate_div,   // divider value from cmd_decoder
    output reg                   sample_en   // single-cycle enable pulse
);

reg [DIV_WIDTH-1:0] cnt;

always @(posedge clk or posedge reset) begin
    if (reset) begin
        cnt       <= 0;
        sample_en <= 1'b0;
    end else begin
        // [FIX] Use >= instead of == so that if rate_div is decreased
        // while cnt already exceeds the new target, the counter resets
        // immediately on the next clock rather than wrapping through the
        // full 27-bit range (~1.3 s stall at 100 MHz).
        if (cnt >= rate_div - 1) begin
            cnt       <= 0;
            sample_en <= 1'b1;  // pulse high for one clock
        end else begin
            cnt       <= cnt + 1;
            sample_en <= 1'b0;
        end
    end
end

endmodule
