`timescale 1ns / 1ps
// =============================================================================
//  uart_tx.v
//  UART Transmitter — 8N1, parameterized baud rate, LSB first.
//
//  Interface:
//    tx_start  : pulse high for one cycle to begin transmission
//    tx_data   : byte to transmit (must be stable when tx_start is high)
//    tx_busy   : high while a byte is being transmitted
//    tx_out    : serial output line (idle = 1)
//
//  Frame format (LSB first):
//    [start=0][D0][D1][D2][D3][D4][D5][D6][D7][stop=1]
//
//  Baud-period accounting:
//    The wire frame is exactly 10 baud periods (correct 8N1 standard):
//      1 start + 8 data + 1 stop = 10 periods.
//    However, tx_busy is held for 11 baud periods — one full guard period
//    after the stop bit has been placed on the wire (bit_cnt == 9 below).
//    This deliberate 1-period guard is necessary for intermediate bytes:
//    tx_fsm fires the next tx_start as soon as !tx_busy, and without the
//    guard that would happen at the very start of the stop-bit period,
//    overwriting the stop bit with the next start bit before the FT2232H
//    receiver has had time to sample its centre.
//    Cost: ~9.9% throughput reduction (11 vs 10 periods per byte).
//    At 115200 baud the 1026-byte frame takes ~97.9 ms instead of ~89.1 ms.
// =============================================================================
module uart_tx #(
    parameter CLK_FREQ  = 100_000_000,
    parameter BAUD_RATE = 115_200
)(
    input  wire       clk,
    input  wire       reset,
    input  wire       tx_start,   // single-cycle start pulse
    input  wire [7:0] tx_data,    // byte to send
    output reg        tx_busy,    // high during transmission
    output reg        tx_out      // serial line
);

// ── Timing constants ─────────────────────────────────────────────────────────
localparam BAUD_TICKS = CLK_FREQ / BAUD_RATE;

// CNT_W = $clog2(BAUD_TICKS).  The register is [CNT_W:0] (one extra bit)
// rather than [CNT_W-1:0] as a safety margin: if BAUD_TICKS happens to be
// an exact power of two, $clog2 returns the exponent and a [CNT_W-1:0]
// counter would wrap at exactly BAUD_TICKS, misfiring one cycle early.
// The extra bit has no area cost at this width.
localparam CNT_W      = $clog2(BAUD_TICKS);

// ── Registers ─────────────────────────────────────────────────────────────────
reg [CNT_W:0] baud_cnt;          // one extra bit — see CNT_W note above
reg [3:0]     bit_cnt;
reg [8:0]     shift_reg;         // 9 bits: [stop | D7..D0]

// ── Transmitter ───────────────────────────────────────────────────────────────
// Start bit is driven to tx_out on the same clock edge that tx_start is seen.
// The busy loop then clocks out the remaining 9 bits (D0–D7 + stop) one per
// BAUD_TICKS, and holds tx_busy for one extra guard period after the stop bit
// (see header comment for why bit_cnt == 9 rather than == 8).
always @(posedge clk or posedge reset) begin
    if (reset) begin
        tx_out    <= 1'b1;
        tx_busy   <= 1'b0;
        baud_cnt  <= 0;
        bit_cnt   <= 0;
        shift_reg <= 9'b111111111;
    end else begin

        if (tx_start && !tx_busy) begin
            // Load 9 remaining bits: [stop=1, D7..D0]
            // Start bit (0) is driven to tx_out immediately this cycle.
            shift_reg <= {1'b1, tx_data};   // 9 bits: stop + 8 data
            tx_out    <= 1'b0;              // start bit — output NOW
            tx_busy   <= 1'b1;
            baud_cnt  <= 0;
            bit_cnt   <= 0;
        end

        else if (tx_busy) begin
            if (baud_cnt == BAUD_TICKS - 1) begin
                baud_cnt  <= 0;
                tx_out    <= shift_reg[0];              // D0..D7, then stop
                shift_reg <= {1'b1, shift_reg[8:1]};   // shift right, pad 1

                if (bit_cnt == 9) begin
                    // bit_cnt 0-7  : data bits D0–D7
                    // bit_cnt 8    : stop bit placed on tx_out
                    // bit_cnt 9    : guard period ends — now safe to drop tx_busy.
                    //   Dropping at bit_cnt==8 (start of stop bit) lets tx_fsm
                    //   fire the next tx_start immediately, which drives tx_out
                    //   low (next start bit) before the receiver samples the
                    //   stop-bit centre — corrupting that frame for the receiver.
                    tx_busy <= 1'b0;
                end else
                    bit_cnt <= bit_cnt + 1;
            end else
                baud_cnt <= baud_cnt + 1;
        end

    end
end

endmodule
