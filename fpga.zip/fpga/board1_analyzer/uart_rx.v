`timescale 1ns / 1ps
// =============================================================================
//  uart_rx.v
//  UART Receiver — 8N1, parameterized baud rate.
//
//  State machine:
//    IDLE  : wait for falling edge (start bit)
//    START : wait BAUD_HALF ticks and verify start bit at centre
//    DATA  : sample 8 data bits, one per BAUD_TICKS (LSB first)
//    STOP  : verify stop bit, assert rx_valid for one clock cycle
//
//  Outputs:
//    rx_data  : received byte (valid only when rx_valid is high)
//    rx_valid : single-cycle pulse when a valid byte is received
// =============================================================================
module uart_rx #(
    parameter CLK_FREQ  = 100_000_000,
    parameter BAUD_RATE = 115_200
)(
    input  wire       clk,
    input  wire       reset,
    input  wire       rx_in,      // synchronised RX line (from sync_2stage)
    output reg  [7:0] rx_data,
    output reg        rx_valid
);

// ── Timing constants ─────────────────────────────────────────────────────────
localparam BAUD_TICKS = CLK_FREQ / BAUD_RATE;   // ticks per bit  (868)
localparam BAUD_HALF  = BAUD_TICKS / 2;          // half-bit delay (434)
localparam CNT_W      = $clog2(BAUD_TICKS);      // counter width  (10)

// ── State encoding ────────────────────────────────────────────────────────────
localparam RX_IDLE  = 2'd0;
localparam RX_START = 2'd1;
localparam RX_DATA  = 2'd2;
localparam RX_STOP  = 2'd3;

// ── Registers ─────────────────────────────────────────────────────────────────
reg [1:0]     state;
reg [CNT_W:0] baud_cnt;     // one extra bit for safety
reg [2:0]     bit_cnt;
reg [7:0]     shift_reg;

// ── FSM ───────────────────────────────────────────────────────────────────────
always @(posedge clk or posedge reset) begin
    if (reset) begin
        state     <= RX_IDLE;
        baud_cnt  <= 0;
        bit_cnt   <= 0;
        shift_reg <= 0;
        rx_data   <= 0;
        rx_valid  <= 1'b0;
    end else begin
        rx_valid <= 1'b0;   // default: pulse low every cycle

        case (state)

            // ── Wait for start bit (line goes low) ───────────────────────
            RX_IDLE: begin
                if (!rx_in) begin
                    baud_cnt <= 0;
                    state    <= RX_START;
                end
            end

            // ── Sample centre of start bit ───────────────────────────────
            RX_START: begin
                if (baud_cnt == BAUD_HALF - 1) begin
                    baud_cnt <= 0;
                    if (!rx_in) begin       // still low — valid start bit
                        bit_cnt <= 0;
                        state   <= RX_DATA;
                    end else
                        state   <= RX_IDLE; // glitch, abort
                end else
                    baud_cnt <= baud_cnt + 1;
            end

            // ── Sample 8 data bits (LSB first) ───────────────────────────
            RX_DATA: begin
                if (baud_cnt == BAUD_TICKS - 1) begin
                    baud_cnt  <= 0;
                    shift_reg <= {rx_in, shift_reg[7:1]};   // shift in LSB first
                    if (bit_cnt == 7)
                        state <= RX_STOP;
                    else
                        bit_cnt <= bit_cnt + 1;
                end else
                    baud_cnt <= baud_cnt + 1;
            end

            // ── Verify stop bit, assert rx_valid ─────────────────────────
            RX_STOP: begin
                if (baud_cnt == BAUD_TICKS - 1) begin
                    baud_cnt <= 0;
                    if (rx_in) begin        // valid stop bit (line high)
                        rx_data  <= shift_reg;
                        rx_valid <= 1'b1;
                    end
                    // invalid stop bit: silently discard frame
                    state <= RX_IDLE;
                end else
                    baud_cnt <= baud_cnt + 1;
            end

            default: state <= RX_IDLE;
        endcase
    end
end

endmodule
