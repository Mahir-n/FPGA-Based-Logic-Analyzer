`timescale 1ns / 1ps
// =============================================================================
//  logic_analyzer_top.v
//  Top-level core of the FPGA Logic Analyzer.
//  Instantiates all submodules and wires them together.
//
//  Submodule hierarchy:
//
//    logic_analyzer_top
//    ├── sync_2stage  (u_sig_sync)   8-bit signal synchronizer
//    ├── sync_2stage  (u_rx_sync)    1-bit UART RX synchronizer
//    ├── uart_rx      (u_uart_rx)    UART receiver (8N1)
//    ├── uart_tx      (u_uart_tx)    UART transmitter (8N1)
//    ├── cmd_decoder  (u_cmd_dec)    UART command → rate_div / trig config
//    ├── sample_divider(u_samp_div)  Programmable sample rate divider
//    ├── trigger_unit (u_trigger)    Configurable edge trigger
//    ├── capture_mem  (u_cap_mem)    1024×8 BRAM capture memory
//    └── tx_fsm       (u_tx_fsm)    Memory → UART TX sender FSM
//
//  UART Command Protocol (PC → FPGA, single byte):
//    0x01–0x12  : sample rate select (see cmd_decoder.v)
//    0x20–0x2F  : trigger config     (see cmd_decoder.v)
//
// =============================================================================
module logic_analyzer_top #(
    parameter CLK_FREQ  = 100_000_000,
    parameter BAUD_RATE = 115_200,
    parameter DEPTH     = 1024,
    parameter DIV_WIDTH = 27
)(
    input  wire        clk,         // 100 MHz system clock
    input  wire        reset,       // active-high synchronous reset (BTNC)
    input  wire        free_run,    // 1 = continuous capture, 0 = wait for trigger
    input  wire [7:0]  signals,     // 8 digital probe inputs
    input  wire        uart_rx,     // UART RX from PC
    output wire        uart_tx      // UART TX to PC
);

localparam ADDR_WIDTH = $clog2(DEPTH);

// =============================================================================
// INTERNAL WIRES
// =============================================================================

// Synchronised signals
wire [7:0] synced_signals;
wire        synced_rx;

// Sampled signals (registered)
reg  [7:0]  sampled;

// UART RX
wire [7:0]  rx_data;
wire         rx_valid;

// Command decoder outputs
wire [DIV_WIDTH-1:0] rate_div;
wire [2:0]           trig_ch;
wire                 trig_edge;

// Sample divider
wire sample_en;

// Trigger
wire triggered;

// Capture memory
wire                  freeze;
wire [ADDR_WIDTH-1:0] rd_addr;
wire [7:0]            rd_data;

// TX FSM
wire tx_start;
wire tx_busy;
wire [7:0] tx_data;
wire send_done;

// =============================================================================
// SIGNAL SAMPLING REGISTER
// Registered one more cycle after the synchronizer for clean setup timing.
// =============================================================================
always @(posedge clk)
    sampled <= synced_signals;

// =============================================================================
// SUBMODULE INSTANTIATIONS
// =============================================================================

// ── 1. 8-bit signal synchronizer ─────────────────────────────────────────────
sync_2stage #(.WIDTH(8)) u_sig_sync (
    .clk (clk),
    .d   (signals),
    .q   (synced_signals)
);

// ── 2. 1-bit UART RX synchronizer ────────────────────────────────────────────
sync_2stage #(.WIDTH(1)) u_rx_sync (
    .clk (clk),
    .d   (uart_rx),
    .q   (synced_rx)
);

// ── 3. UART Receiver ─────────────────────────────────────────────────────────
uart_rx #(
    .CLK_FREQ  (CLK_FREQ),
    .BAUD_RATE (BAUD_RATE)
) u_uart_rx (
    .clk      (clk),
    .reset    (reset),
    .rx_in    (synced_rx),
    .rx_data  (rx_data),
    .rx_valid (rx_valid)
);

// ── 4. UART Transmitter ───────────────────────────────────────────────────────
uart_tx #(
    .CLK_FREQ  (CLK_FREQ),
    .BAUD_RATE (BAUD_RATE)
) u_uart_tx (
    .clk      (clk),
    .reset    (reset),
    .tx_start (tx_start),
    .tx_data  (tx_data),
    .tx_busy  (tx_busy),
    .tx_out   (uart_tx)
);

// ── 5. Command Decoder ────────────────────────────────────────────────────────
cmd_decoder #(
    .DIV_WIDTH (DIV_WIDTH)
) u_cmd_dec (
    .clk       (clk),
    .reset     (reset),
    .rx_valid  (rx_valid),
    .rx_data   (rx_data),
    .rate_div  (rate_div),
    .trig_ch   (trig_ch),
    .trig_edge (trig_edge)
);

// ── 6. Sample Rate Divider ────────────────────────────────────────────────────
sample_divider #(
    .DIV_WIDTH (DIV_WIDTH)
) u_samp_div (
    .clk       (clk),
    .reset     (reset),
    .rate_div  (rate_div),
    .sample_en (sample_en)
);

// ── 7. Trigger Unit ───────────────────────────────────────────────────────────
trigger_unit u_trigger (
    .clk        (clk),
    .reset      (reset),
    .sample_en  (sample_en),
    .sampled    (sampled),
    .trig_ch    (trig_ch),
    .trig_edge  (trig_edge),
    .free_run   (free_run),
    .send_done  (send_done),
    .triggered  (triggered)
);

// ── 8. Capture Memory ─────────────────────────────────────────────────────────
capture_mem #(
    .DEPTH      (DEPTH),
    .ADDR_WIDTH (ADDR_WIDTH)
) u_cap_mem (
    .clk        (clk),
    .reset      (reset),
    .sample_en  (sample_en),
    .triggered  (triggered),
    .sampled    (sampled),
    .send_done  (send_done),
    .rd_addr    (rd_addr),
    .rd_data    (rd_data),
    .freeze     (freeze)
);

// ── 9. TX Sender FSM ──────────────────────────────────────────────────────────
tx_fsm #(
    .DEPTH      (DEPTH),
    .ADDR_WIDTH (ADDR_WIDTH)
) u_tx_fsm (
    .clk        (clk),
    .reset      (reset),
    .freeze     (freeze),
    .rd_addr    (rd_addr),
    .rd_data    (rd_data),
    .tx_busy    (tx_busy),
    .tx_start   (tx_start),
    .tx_data    (tx_data),
    .send_done  (send_done)
);

endmodule
