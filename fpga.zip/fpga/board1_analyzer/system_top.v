`timescale 1ns / 1ps
// =============================================================================
//  system_top.v  (MODIFIED for external signal source)
//  Board 1 — Logic Analyzer Board
//  Nexys A7-100T
//
//  CHANGE FROM ORIGINAL:
//    The internal signal_generator module has been removed. Test signals
//    now come from a SECOND Nexys A7 board via PMOD JB (8-bit input).
//    SW_MODE has been removed since there is no internal/external mux.
//
//  Probe input:
//    PMOD JB[7:0]  → 8 external probe channels (from Board 2)
//
//  Controls:
//    SW[8] (SW_FREE)  → free_run mode (1 = continuous, 0 = wait for trigger)
//    BTNC             → active-high reset
//
//  All trigger configuration (channel, edge) is done from the Python GUI
//  via UART — no physical switches required for trigger control.
// =============================================================================
module system_top (
    input  wire        CLK100MHZ,
    input  wire        BTNC,        // reset — active high
    input  wire        SW_FREE,     // free-run enable   (SW[8])
    input  wire [7:0]  JB,          // PMOD JB — 8 probe inputs from Board 2
    input  wire        UART_RX,     // from USB-UART bridge
    output wire        UART_TX      // to   USB-UART bridge
);

// ── Reset synchronizer ────────────────────────────────────────────────────────
reg rst_meta, rst_sync;
always @(posedge CLK100MHZ or posedge BTNC) begin
    if (BTNC) begin
        rst_meta <= 1'b1;
        rst_sync <= 1'b1;
    end else begin
        rst_meta <= 1'b0;
        rst_sync <= rst_meta;
    end
end
wire reset_synced = rst_sync;

// ── Synchronize control switch ───────────────────────────────────────────────
wire sw_free_synced;

sync_2stage #(.WIDTH(1)) u_sync_free (
    .clk (CLK100MHZ),
    .d   (SW_FREE),
    .q   (sw_free_synced)
);

// ── Core logic analyzer ───────────────────────────────────────────────────────
// Probe signals (JB) are synchronized inside logic_analyzer_top via
// sync_2stage — no additional synchronization needed here.
logic_analyzer_top #(
    .CLK_FREQ  (100_000_000),
    .BAUD_RATE (115_200),
    .DEPTH     (1024),
    .DIV_WIDTH (27)
) u_analyzer (
    .clk      (CLK100MHZ),
    .reset    (reset_synced),
    .free_run (sw_free_synced),
    .signals  (JB),              // probe PMOD JB directly
    .uart_rx  (UART_RX),
    .uart_tx  (UART_TX)
);

endmodule
