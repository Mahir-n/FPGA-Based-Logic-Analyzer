`timescale 1ns / 1ps
// =============================================================================
//  btn_debounce.v
//  Mechanical button debouncer with single-cycle pulse output.
//
//  Physical buttons bounce for ~5-20ms when pressed. This module requires
//  the input to be stable for ~10ms (1,000,000 clocks at 100 MHz) before
//  accepting the new level. btn_pulse goes high for exactly one clock cycle
//  on the rising edge of the debounced signal.
// =============================================================================
module btn_debounce (
    input  wire clk,
    input  wire reset,
    input  wire btn_in,       // raw button input (active high)
    output reg  btn_pulse     // single-cycle pulse on button press
);

localparam COUNT_MAX = 1_000_000;  // ~10 ms at 100 MHz

reg [19:0] cnt;
reg        btn_stable;
reg        btn_prev;

always @(posedge clk or posedge reset) begin
    if (reset) begin
        cnt        <= 0;
        btn_stable <= 1'b0;
        btn_prev   <= 1'b0;
        btn_pulse  <= 1'b0;
    end else begin
        // Edge detection on debounced output
        btn_prev  <= btn_stable;
        btn_pulse <= (btn_stable & ~btn_prev);  // rising edge only

        // Debounce counter: input must stay different from stable
        // for COUNT_MAX consecutive clocks to be accepted
        if (btn_in != btn_stable) begin
            if (cnt >= COUNT_MAX - 1) begin
                btn_stable <= btn_in;
                cnt        <= 0;
            end else
                cnt <= cnt + 1;
        end else
            cnt <= 0;
    end
end

endmodule
