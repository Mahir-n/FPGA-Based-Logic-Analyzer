`timescale 1ns / 1ps
// =============================================================================
//  freq_divider.v
//  Programmable square wave generator for a single channel.
//
//  Toggles sq_out every div_val clock cycles, producing a square wave
//  with period = 2 * div_val * T_clk.
//
//  At 100 MHz system clock:
//    div_val = 50,000,000  →  1 Hz
//    div_val = 50          →  1 MHz
//    div_val = 5           →  10 MHz
//
//  Uses >= comparison so that if div_val is decreased while the counter
//  already exceeds the new target, the counter resets immediately rather
//  than wrapping through the full 26-bit range.
// =============================================================================
module freq_divider (
    input  wire        clk,
    input  wire        reset,
    input  wire [25:0] div_val,   // half-period in clock cycles
    output reg         sq_out     // square wave output
);

reg [25:0] cnt;

always @(posedge clk or posedge reset) begin
    if (reset) begin
        cnt    <= 0;
        sq_out <= 1'b0;
    end else if (cnt >= div_val - 1) begin
        cnt    <= 0;
        sq_out <= ~sq_out;    // toggle output
    end else begin
        cnt <= cnt + 1;
    end
end

endmodule
