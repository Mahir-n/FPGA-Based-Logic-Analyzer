`timescale 1ns / 1ps
// =============================================================================
//  seg7_driver.v
//  8-digit multiplexed 7-segment display driver for Nexys A7-100T.
//
//  Input: 8 character codes (4 bits each, packed into 32-bit bus).
//         char_codes[31:28] = leftmost digit (digit 7)
//         char_codes[3:0]   = rightmost digit (digit 0)
//
//  Character codes:
//    0x0–0x9 : digits 0–9
//    0xA     : letter 'C'
//    0xB     : letter 'H'
//    0xF     : blank (all segments off)
//
//  Outputs active-low cathodes and anodes (Nexys A7 convention).
//  Refresh rate: ~1 KHz per digit → ~125 Hz full scan (flicker-free).
// =============================================================================
module seg7_driver (
    input  wire        clk,
    input  wire        reset,
    input  wire [31:0] char_codes,  // 8 x 4-bit character codes
    output reg  [6:0]  seg,         // {CG,CF,CE,CD,CC,CB,CA} active low
    output reg         dp,          // decimal point, active low
    output reg  [7:0]  an           // active low anodes
);

// ── Refresh counter ─────────────────────────────────────────────────────────
// 100 MHz / 100,000 = 1 KHz per digit position
localparam REFRESH = 100_000;

reg [16:0] ref_cnt;
reg [2:0]  dig_sel;

always @(posedge clk or posedge reset) begin
    if (reset) begin
        ref_cnt <= 0;
        dig_sel <= 0;
    end else if (ref_cnt >= REFRESH - 1) begin
        ref_cnt <= 0;
        dig_sel <= dig_sel + 1;
    end else
        ref_cnt <= ref_cnt + 1;
end

// ── Extract current digit's character code ──────────────────────────────────
// dig_sel 0 = rightmost (char_codes[3:0])
// dig_sel 7 = leftmost  (char_codes[31:28])
wire [3:0] cur_char = char_codes[dig_sel * 4 +: 4];

// ── Character to 7-segment lookup (active low: 0 = segment ON) ──────────────
//  Segment map:  seg[6]=g  seg[5]=f  seg[4]=e  seg[3]=d  seg[2]=c  seg[1]=b  seg[0]=a
//
//       aaaa
//      f    b
//      f    b
//       gggg
//      e    c
//      e    c
//       dddd
//
reg [6:0] seg7;

always @(*) begin
    case (cur_char)
        4'h0:    seg7 = 7'b100_0000;  // 0
        4'h1:    seg7 = 7'b111_1001;  // 1
        4'h2:    seg7 = 7'b010_0100;  // 2
        4'h3:    seg7 = 7'b011_0000;  // 3
        4'h4:    seg7 = 7'b001_1001;  // 4
        4'h5:    seg7 = 7'b001_0010;  // 5
        4'h6:    seg7 = 7'b000_0010;  // 6
        4'h7:    seg7 = 7'b111_1000;  // 7
        4'h8:    seg7 = 7'b000_0000;  // 8
        4'h9:    seg7 = 7'b001_0000;  // 9
        4'hA:    seg7 = 7'b100_0110;  // C  (segments a,d,e,f)
        4'hB:    seg7 = 7'b000_1001;  // H  (segments b,c,e,f,g)
        4'hF:    seg7 = 7'b111_1111;  // blank
        default: seg7 = 7'b111_1111;  // blank
    endcase
end

// ── Drive outputs ───────────────────────────────────────────────────────────
always @(*) begin
    an       = 8'b1111_1111;       // all off
    an[dig_sel] = 1'b0;            // activate current digit
    seg      = seg7;
    dp       = 1'b1;               // DP always off (active low)
end

endmodule
