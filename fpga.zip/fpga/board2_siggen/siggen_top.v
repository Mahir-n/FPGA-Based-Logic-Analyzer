`timescale 1ns / 1ps
// =============================================================================
//  siggen_top.v  (v3 - fixed multi-driver bug)
//  BOARD 2 - Configurable 8-Channel Signal Generator
//  Nexys A7-100T
//
//  ── Controls ────────────────────────────────────────────────────────────
//    SW[2:0]  → channel select (CH0-CH7)
//    SW[6:4]  → step size select:
//                 000 =      1 Hz     100 =  10 KHz
//                 001 =     10 Hz     101 = 100 KHz
//                 010 =    100 Hz     110 =   1 MHz
//                 011 =   1 KHz      111 =  10 MHz
//    BTNU     → increase frequency by step size
//    BTND     → decrease frequency by step size
//    BTNC     → reset all channels to defaults
//
//  ── Outputs ─────────────────────────────────────────────────────────────
//    PMOD JA[7:0]  → 8 square wave signals
//    7-Segment     → selected channel's frequency in Hz (leading zeros
//                    blanked), updates live on each button press
//    LED[0]        → Hz indicator   (freq < 1000)
//    LED[1]        → KHz indicator  (1000 <= freq < 1000000)
//    LED[2]        → MHz indicator  (freq >= 1000000)
//
//  ── Frequency Range ─────────────────────────────────────────────────────
//    Minimum:         1 Hz   (div = 50,000,000)
//    Maximum: 10,000,000 Hz  (div = 5)
// =============================================================================
module siggen_top (
    input  wire        CLK100MHZ,
    input  wire        BTNC,
    input  wire        BTNU,
    input  wire        BTND,
    input  wire [6:0]  SW,
    output wire [7:0]  JA,
    output wire [6:0]  SEG,
    output wire        DP,
    output wire [7:0]  AN,
    output reg  [2:0]  LED
);

localparam HALF_PERIOD_CONST = 27'd50_000_000;
localparam FREQ_MAX          = 27'd10_000_000;
localparam FREQ_MIN          = 27'd1;

// ═════════════════════════════════════════════════════════════════════════════
//  RESET SYNCHRONIZER
// ═════════════════════════════════════════════════════════════════════════════
reg rst_meta, rst_sync;
always @(posedge CLK100MHZ or posedge BTNC) begin
    if (BTNC) begin rst_meta <= 1'b1; rst_sync <= 1'b1;
    end else begin  rst_meta <= 1'b0; rst_sync <= rst_meta; end
end
wire reset = rst_sync;

// ═════════════════════════════════════════════════════════════════════════════
//  SWITCH SYNCHRONIZER
// ═════════════════════════════════════════════════════════════════════════════
reg [6:0] sw_meta, sw_sync;
always @(posedge CLK100MHZ) begin sw_meta <= SW; sw_sync <= sw_meta; end
wire [2:0] sel_ch   = sw_sync[2:0];
wire [2:0] sel_step = sw_sync[6:4];

// ═════════════════════════════════════════════════════════════════════════════
//  BUTTON DEBOUNCERS
// ═════════════════════════════════════════════════════════════════════════════
wire up_pulse, dn_pulse;
btn_debounce u_deb_up (.clk(CLK100MHZ), .reset(reset), .btn_in(BTNU), .btn_pulse(up_pulse));
btn_debounce u_deb_dn (.clk(CLK100MHZ), .reset(reset), .btn_in(BTND), .btn_pulse(dn_pulse));

// ═════════════════════════════════════════════════════════════════════════════
//  STEP SIZE LOOKUP
// ═════════════════════════════════════════════════════════════════════════════
reg [26:0] step_val;
always @(*) begin
    case (sel_step)
        3'd0: step_val = 27'd1;
        3'd1: step_val = 27'd10;
        3'd2: step_val = 27'd100;
        3'd3: step_val = 27'd1_000;
        3'd4: step_val = 27'd10_000;
        3'd5: step_val = 27'd100_000;
        3'd6: step_val = 27'd1_000_000;
        3'd7: step_val = 27'd10_000_000;
        default: step_val = 27'd1;
    endcase
end

// ═════════════════════════════════════════════════════════════════════════════
//  PER-CHANNEL FREQUENCY + DIVIDER REGISTERS
// ═════════════════════════════════════════════════════════════════════════════
reg [26:0] freq_hz [0:7];
reg [26:0] div_val [0:7];

// Candidate new frequencies (combinational)
wire [27:0] freq_plus  = {1'b0, freq_hz[sel_ch]} + {1'b0, step_val};
wire [27:0] freq_minus = {1'b0, freq_hz[sel_ch]} - {1'b0, step_val};

// ═════════════════════════════════════════════════════════════════════════════
//  UNIFIED UPDATE + DIVIDER STATE MACHINE
//  ─────────────────────────────────────────────────────────────────────────
//  All divider registers and freq/div_val registers are driven from this
//  single always block to avoid multi-driver conflicts.
//
//  States:
//    S_IDLE  - wait for button press
//    S_CALC  - run shift-subtract divider (27 clock cycles)
//    S_STORE - latch computed divider into div_val[ch]
// ═════════════════════════════════════════════════════════════════════════════
localparam S_IDLE  = 2'd0;
localparam S_CALC  = 2'd1;
localparam S_STORE = 2'd2;

reg [1:0]  state;
reg [2:0]  upd_ch;         // channel being updated

// Divider working registers
reg [26:0] d_dividend;     // = HALF_PERIOD_CONST (stored for bit indexing)
reg [26:0] d_divisor;      // = new frequency in Hz
reg [26:0] d_quotient;     // shift register for result
reg [26:0] d_remainder;    // running remainder
reg [4:0]  d_bit;          // current bit being processed (26 downto 0)

always @(posedge CLK100MHZ or posedge reset) begin
    if (reset) begin
        freq_hz[0] <= 27'd10_000_000;  div_val[0] <= 27'd5;
        freq_hz[1] <= 27'd1_000_000;   div_val[1] <= 27'd50;
        freq_hz[2] <= 27'd100_000;     div_val[2] <= 27'd500;
        freq_hz[3] <= 27'd10_000;      div_val[3] <= 27'd5_000;
        freq_hz[4] <= 27'd1_000;       div_val[4] <= 27'd50_000;
        freq_hz[5] <= 27'd100;         div_val[5] <= 27'd500_000;
        freq_hz[6] <= 27'd10;          div_val[6] <= 27'd5_000_000;
        freq_hz[7] <= 27'd1;           div_val[7] <= 27'd50_000_000;

        state       <= S_IDLE;
        upd_ch      <= 0;
        d_dividend  <= 0;
        d_divisor   <= 1;
        d_quotient  <= 0;
        d_remainder <= 0;
        d_bit       <= 0;
    end else begin

        case (state)
        // ─────────────────────────────────────────────────────────────────
        S_IDLE: begin
            if (up_pulse) begin
                // Check upper bound
                if (freq_plus <= {1'b0, FREQ_MAX}) begin
                    freq_hz[sel_ch] <= freq_plus[26:0];
                    // Prepare divider: 50,000,000 / new_freq
                    d_dividend  <= HALF_PERIOD_CONST;
                    d_divisor   <= freq_plus[26:0];
                    d_quotient  <= 0;
                    d_remainder <= 0;
                    d_bit       <= 5'd26;
                    upd_ch      <= sel_ch;
                    state       <= S_CALC;
                end
            end else if (dn_pulse) begin
                // Check lower bound and underflow
                if (!freq_minus[27] && freq_minus[26:0] >= FREQ_MIN) begin
                    freq_hz[sel_ch] <= freq_minus[26:0];
                    d_dividend  <= HALF_PERIOD_CONST;
                    d_divisor   <= freq_minus[26:0];
                    d_quotient  <= 0;
                    d_remainder <= 0;
                    d_bit       <= 5'd26;
                    upd_ch      <= sel_ch;
                    state       <= S_CALC;
                end
            end
        end

        // ─────────────────────────────────────────────────────────────────
        S_CALC: begin
            // Shift-subtract division: one bit per clock cycle
            // Shift remainder left, bring in next dividend bit
            if ({d_remainder[25:0], d_dividend[d_bit]} >= d_divisor) begin
                d_remainder <= {d_remainder[25:0], d_dividend[d_bit]} - d_divisor;
                d_quotient  <= {d_quotient[25:0], 1'b1};
            end else begin
                d_remainder <= {d_remainder[25:0], d_dividend[d_bit]};
                d_quotient  <= {d_quotient[25:0], 1'b0};
            end

            if (d_bit == 0)
                state <= S_STORE;
            else
                d_bit <= d_bit - 1;
        end

        // ─────────────────────────────────────────────────────────────────
        S_STORE: begin
            // Clamp minimum divider to 2 (avoids div=0 or div=1 edge cases)
            div_val[upd_ch] <= (d_quotient < 2) ? 27'd2 : d_quotient;
            state <= S_IDLE;
        end

        default: state <= S_IDLE;
        endcase
    end
end

// ═════════════════════════════════════════════════════════════════════════════
//  8 FREQUENCY DIVIDERS
// ═════════════════════════════════════════════════════════════════════════════
genvar g;
generate
    for (g = 0; g < 8; g = g + 1) begin : gen_ch
        freq_divider u_div (
            .clk     (CLK100MHZ),
            .reset   (reset),
            .div_val (div_val[g]),
            .sq_out  (JA[g])
        );
    end
endgenerate

// ═════════════════════════════════════════════════════════════════════════════
//  7-SEGMENT: Binary-to-BCD (double-dabble) + leading zero blanking
// ═════════════════════════════════════════════════════════════════════════════
wire [26:0] display_freq = freq_hz[sel_ch];

reg [31:0] bcd;
integer i;
always @(*) begin
    bcd = 32'd0;
    for (i = 26; i >= 0; i = i - 1) begin
        if (bcd[3:0]   >= 5) bcd[3:0]   = bcd[3:0]   + 3;
        if (bcd[7:4]   >= 5) bcd[7:4]   = bcd[7:4]   + 3;
        if (bcd[11:8]  >= 5) bcd[11:8]  = bcd[11:8]  + 3;
        if (bcd[15:12] >= 5) bcd[15:12] = bcd[15:12] + 3;
        if (bcd[19:16] >= 5) bcd[19:16] = bcd[19:16] + 3;
        if (bcd[23:20] >= 5) bcd[23:20] = bcd[23:20] + 3;
        if (bcd[27:24] >= 5) bcd[27:24] = bcd[27:24] + 3;
        if (bcd[31:28] >= 5) bcd[31:28] = bcd[31:28] + 3;
        bcd = {bcd[30:0], display_freq[i]};
    end
end

// Leading zero blanking
reg [31:0] char_codes;
always @(*) begin
    char_codes = bcd;
    if (bcd[31:28] == 0) begin char_codes[31:28] = 4'hF;
    if (bcd[27:24] == 0) begin char_codes[27:24] = 4'hF;
    if (bcd[23:20] == 0) begin char_codes[23:20] = 4'hF;
    if (bcd[19:16] == 0) begin char_codes[19:16] = 4'hF;
    if (bcd[15:12] == 0) begin char_codes[15:12] = 4'hF;
    if (bcd[11:8]  == 0) begin char_codes[11:8]  = 4'hF;
    if (bcd[7:4]   == 0) begin char_codes[7:4]   = 4'hF;
    end end end end end end end
end

// ═════════════════════════════════════════════════════════════════════════════
//  7-SEGMENT DRIVER
// ═════════════════════════════════════════════════════════════════════════════
seg7_driver u_display (
    .clk(CLK100MHZ), .reset(reset), .char_codes(char_codes),
    .seg(SEG), .dp(DP), .an(AN)
);

// ═════════════════════════════════════════════════════════════════════════════
//  UNIT INDICATOR LEDs
// ═════════════════════════════════════════════════════════════════════════════
always @(*) begin
    if      (display_freq >= 27'd1_000_000) LED = 3'b100;
    else if (display_freq >= 27'd1_000)     LED = 3'b010;
    else                                    LED = 3'b001;
end

endmodule