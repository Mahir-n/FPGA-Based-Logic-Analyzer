"""
=============================================================================
  FPGA Logic Analyzer — Real-Time 8-Channel Waveform Viewer
  Board  : Nexys A7-100T   |   UART : 115200 baud 8N1
  DEPTH  : 1024 samples    |   8 channels

  ── UART Stream Format (FPGA -> PC) ──────────────────────────────────────
  Each capture = [0xAA] [0x55] [mem[0]] [mem[1]] ... [mem[1023]] = 1026 bytes
  Python scans for 0xAA 0x55 header to find frame boundaries — immune to
  mid-stream connects and automatic resync after any data loss.

  ── UART Command Protocol (PC -> FPGA, single byte) ──────────────────────
  Rate commands  (0x01 – 0x12):
    0x01=100MHz  0x02=50MHz   0x03=25MHz   0x04=10MHz   0x05=5MHz
    0x06=1MHz    0x07=500KHz  0x08=100KHz  0x09=50KHz   0x0A=10KHz
    0x0B=5KHz    0x0C=1KHz    0x0D=500Hz   0x0E=100Hz   0x0F=50Hz
    0x10=10Hz    0x11=5Hz     0x12=1Hz

  Trigger commands  (0x20 – 0x2F):
    Upper nibble 0x2 = trigger config
    Bit  [3] : edge   0=rising  1=falling
    Bits [2:0]: channel  0-7
    Examples: 0x20=rising CH0  0x28=falling CH0  0x25=rising CH5  0x2F=falling CH7

  Known limitations:
    - If the USB cable is disconnected, the reader thread exits and will not
      automatically reconnect.  Use the "Reconnect" button to re-establish
      the connection to the same port without restarting the application.

  Install:
    pip install pyserial matplotlib numpy
  Run:
    python logic_analyzer_viewer.py [COM_PORT]
=============================================================================
"""

import sys, threading, queue
import numpy as np
import serial, serial.tools.list_ports
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.animation import FuncAnimation
from matplotlib.widgets import Button
import warnings
warnings.filterwarnings("ignore")

# =============================================================================
# CONSTANTS
# =============================================================================
BAUD_RATE = 115_200
DEPTH     = 1024
NUM_CH    = 8

# (display label, Hz, FPGA command byte)
RATE_OPTIONS = [
    ("100 MHz", 100_000_000, 0x01),
    (" 50 MHz",  50_000_000, 0x02),
    (" 25 MHz",  25_000_000, 0x03),
    (" 10 MHz",  10_000_000, 0x04),
    ("  5 MHz",   5_000_000, 0x05),
    ("  1 MHz",   1_000_000, 0x06),
    ("500 KHz",     500_000, 0x07),
    ("100 KHz",     100_000, 0x08),
    (" 50 KHz",      50_000, 0x09),
    (" 10 KHz",      10_000, 0x0A),
    ("  5 KHz",       5_000, 0x0B),
    ("  1 KHz",       1_000, 0x0C),
    ("500 Hz ",         500, 0x0D),
    ("100 Hz ",         100, 0x0E),
    (" 50 Hz ",          50, 0x0F),
    (" 10 Hz ",          10, 0x10),
    ("  5 Hz ",           5, 0x11),
    ("  1 Hz ",           1, 0x12),
]

# Trigger channel options
TRIG_CH_OPTIONS = ["CH0", "CH1", "CH2", "CH3", "CH4", "CH5", "CH6", "CH7"]

# Trigger edge options  (label, edge_bit)
TRIG_EDGE_OPTIONS = [
    ("Rising  ↑", 0),
    ("Falling ↓", 1),
]

CHANNEL_NAMES = [
    "CH0", "CH1", "CH2", "CH3",
    "CH4", "CH5", "CH6", "CH7",
]
COLORS = [
    "#00FF41", "#FF6B6B", "#4ECDC4", "#FFE66D",
    "#A8E6CF", "#FF8B94", "#B5EAD7", "#C7CEEA",
]


# =============================================================================
# UTILITY
# =============================================================================
def find_nexys_port():
    for p in serial.tools.list_ports.comports():
        if p.vid == 0x0403 and p.pid == 0x6010:
            return p.device
    ports = serial.tools.list_ports.comports()
    return ports[0].device if ports else None


def make_trigger_byte(channel, edge):
    """
    Encode trigger config as single UART byte.
    Upper nibble = 0x2 (trigger command marker)
    Bit [3]    = edge  (0=rising, 1=falling)
    Bits [2:0] = channel (0-7)
    """
    return 0x20 | ((edge & 0x1) << 3) | (channel & 0x7)


# =============================================================================
# DROPDOWN WIDGET — pure matplotlib, no extra libraries
# =============================================================================
class DropdownWidget:
    """
    Click-to-open dropdown built entirely from matplotlib primitives.
    List grows upward from the header bar.

    Parameters
    ----------
    fig        : matplotlib Figure
    rect       : [left, bottom, width, height] in figure coords (header position)
    options    : list[str]
    on_select  : callable(label: str, index: int)
    init_index : int
    label_text : str  — small label printed above the header
    """

    C_HDR_BG   = "#313244"
    C_LIST_BG  = "#1E1E2E"
    C_SELECTED = "#3D4058"
    C_HOVER    = "#45475A"
    C_BORDER   = "#585B70"
    C_TEXT     = "#CDD6F4"
    C_ACCENT   = "#89B4FA"
    C_ACTIVE   = "#00FF41"

    def __init__(self, fig, rect, options, on_select,
                 init_index=0, label_text=""):
        self.fig       = fig
        self.options   = options
        self.on_select = on_select
        self.current   = init_index
        self.open      = False
        self._hover    = -1

        lx, ly, lw, lh = rect

        # Optional label above header
        if label_text:
            fig.text(lx, ly + lh + 0.004, label_text,
                     fontsize=7.5, color=self.C_ACCENT,
                     family="monospace", fontweight="bold")

        # ── Header ────────────────────────────────────────────────────────
        self.ax_hdr = fig.add_axes([lx, ly, lw, lh], zorder=5)
        self.ax_hdr.set_facecolor(self.C_HDR_BG)
        for sp in self.ax_hdr.spines.values():
            sp.set_edgecolor(self.C_BORDER); sp.set_linewidth(1.1)
        self.ax_hdr.set_xticks([]); self.ax_hdr.set_yticks([])

        self.hdr_text = self.ax_hdr.text(
            0.07, 0.50, f" {options[init_index]}",
            transform=self.ax_hdr.transAxes,
            va="center", ha="left",
            fontsize=8.5, color=self.C_TEXT,
            family="monospace", fontweight="bold",
        )
        self.arrow = self.ax_hdr.text(
            0.87, 0.50, "v",
            transform=self.ax_hdr.transAxes,
            va="center", ha="left",
            fontsize=9, color=self.C_ACCENT, family="monospace",
        )

        # ── Drop list ─────────────────────────────────────────────────────
        n = len(options)
        self.ax_list = fig.add_axes(
            [lx, ly + lh, lw, lh * n], zorder=20
        )
        self.ax_list.set_facecolor(self.C_LIST_BG)
        for sp in self.ax_list.spines.values():
            sp.set_edgecolor(self.C_BORDER); sp.set_linewidth(1.1)
        self.ax_list.set_xticks([]); self.ax_list.set_yticks([])
        self.ax_list.set_xlim(0, 1)
        self.ax_list.set_ylim(0, n)
        self.ax_list.set_visible(False)

        self.item_bgs   = []
        self.item_texts = []
        for i, label in enumerate(options):
            row = n - 1 - i
            bg = self.ax_list.axhspan(
                row, row + 1,
                facecolor=self.C_SELECTED if i == init_index else self.C_LIST_BG,
                edgecolor="#45475A", linewidth=0.4,
            )
            col = self.C_ACTIVE if i == init_index else self.C_TEXT
            fw  = "bold" if i == init_index else "normal"
            txt = self.ax_list.text(
                0.08, row + 0.50, label,
                va="center", ha="left",
                fontsize=8, color=col,
                family="monospace", fontweight=fw,
            )
            self.item_bgs.append(bg)
            self.item_texts.append(txt)

        fig.canvas.mpl_connect("button_press_event",  self._on_click)
        fig.canvas.mpl_connect("motion_notify_event", self._on_hover)

    # ── helpers ───────────────────────────────────────────────────────────────
    def _row_state(self, idx, state):
        bg_c  = {
            "normal":   self.C_LIST_BG,
            "hover":    self.C_HOVER,
            "selected": self.C_SELECTED,
        }[state]
        txt_c = self.C_ACTIVE if state == "selected" else self.C_TEXT
        fw    = "bold" if state == "selected" else "normal"
        self.item_bgs[idx].set_facecolor(bg_c)
        self.item_texts[idx].set_color(txt_c)
        self.item_texts[idx].set_fontweight(fw)

    def _open(self):
        self.open = True
        self.ax_list.set_visible(True)
        self.arrow.set_text("^")
        self.fig.canvas.draw_idle()

    def _close(self):
        self.open = False
        self.ax_list.set_visible(False)
        self.arrow.set_text("v")
        if self._hover >= 0:
            prev = "selected" if self._hover == self.current else "normal"
            self._row_state(self._hover, prev)
            self._hover = -1
        self.fig.canvas.draw_idle()

    def _select(self, idx):
        self._row_state(self.current, "normal")
        self.current = idx
        self._row_state(idx, "selected")
        self.hdr_text.set_text(f" {self.options[idx]}")
        self._close()
        self.on_select(self.options[idx], idx)

    # ── event handlers ────────────────────────────────────────────────────────
    def _on_click(self, event):
        if event.inaxes == self.ax_hdr:
            self._close() if self.open else self._open()
            return
        if self.open and event.inaxes == self.ax_list:
            if event.ydata is not None:
                idx = len(self.options) - 1 - int(event.ydata)
                if 0 <= idx < len(self.options):
                    self._select(idx)
            return
        if self.open:
            self._close()

    def _on_hover(self, event):
        if not self.open or event.inaxes != self.ax_list:
            if self._hover >= 0:
                prev = "selected" if self._hover == self.current else "normal"
                self._row_state(self._hover, prev)
                self._hover = -1
                self.fig.canvas.draw_idle()
            return
        if event.ydata is not None:
            idx = len(self.options) - 1 - int(event.ydata)
            if 0 <= idx < len(self.options) and idx != self._hover:
                if self._hover >= 0:
                    prev = "selected" if self._hover == self.current else "normal"
                    self._row_state(self._hover, prev)
                self._hover = idx
                if idx != self.current:
                    self._row_state(idx, "hover")
                self.fig.canvas.draw_idle()


# =============================================================================
# SERIAL READER THREAD
# =============================================================================
class SerialReader(threading.Thread):
    def __init__(self, port, data_q, status_q):
        super().__init__(daemon=True)
        self.port          = port
        self.data_q        = data_q
        self.status_q      = status_q
        self.running       = True
        self.ser           = None
        self._lock         = threading.Lock()
        self.capture_count = 0

    def send_byte(self, byte_val):
        """Send a single command byte to the FPGA."""
        if self.ser and self.ser.is_open:
            with self._lock:
                try:
                    self.ser.write(bytes([byte_val]))
                    self.ser.flush()
                    print(f"  [TX]  Command  ->  0x{byte_val:02X}")
                except serial.SerialException as e:
                    self.status_q.put(("err", f"Write error: {e}"))

    def send_rate(self, cmd_byte):
        """Send sample rate command byte (0x01-0x12)."""
        self.send_byte(cmd_byte)

    def send_trigger(self, channel, edge):
        """
        Send trigger config to FPGA.
        channel : int 0-7
        edge    : int 0=rising, 1=falling
        """
        cmd = make_trigger_byte(channel, edge)
        self.send_byte(cmd)

    def run(self):
        try:
            self.ser = serial.Serial(
                self.port, BAUD_RATE,
                bytesize=8, parity='N', stopbits=1, timeout=2.0,
            )
            # Discard any partial frame already sitting in the OS buffer from
            # a mid-transmission connect.  Without this the first assembled
            # "frame" would be a mix of the tail of one capture and the head
            # of the next, corrupting all subsequent frames too.
            self.ser.reset_input_buffer()
            self.status_q.put(("ok", f"Connected: {self.port} @ {BAUD_RATE} baud"))
        except serial.SerialException as e:
            self.status_q.put(("err", str(e)))
            return

        FRAME_SIZE  = DEPTH               # 1024 data bytes per frame
        HEADER      = bytes([0xAA, 0x55])
        PACKET_SIZE = len(HEADER) + FRAME_SIZE   # 1026 bytes total

        buf = bytearray()
        while self.running:
            try:
                waiting = self.ser.in_waiting or 1
                chunk   = self.ser.read(waiting)
                if not chunk:
                    continue
                buf.extend(chunk)

                # Scan for 0xAA 0x55 header rather than blindly slicing every
                # DEPTH bytes.  This way, even if we connect mid-stream or
                # lose sync, we automatically re-lock on the next valid frame
                # boundary without any manual intervention.
                while True:
                    # Need at least header + full frame to attempt a decode
                    if len(buf) < PACKET_SIZE:
                        break

                    # Search for the sync header
                    idx = buf.find(HEADER)

                    if idx == -1:
                        # Header not found — discard all but the last byte
                        # (which might be the first byte of a split header)
                        buf = buf[-1:]
                        break

                    if idx > 0:
                        # Bytes before the header are misaligned data — discard
                        discarded = idx
                        buf = buf[idx:]
                        self.status_q.put(("sync", discarded))

                    # Now buf starts with 0xAA 0x55
                    if len(buf) < PACKET_SIZE:
                        break   # wait for more data

                    # Extract exactly DEPTH bytes after the 2-byte header
                    frame = bytes(buf[len(HEADER) : PACKET_SIZE])
                    buf   = buf[PACKET_SIZE:]   # consume the full packet

                    arr  = np.frombuffer(frame, dtype=np.uint8)
                    bits = np.unpackbits(arr.reshape(-1, 1), axis=1)[:, ::-1]
                    self.capture_count += 1

                    try:
                        self.data_q.put_nowait(bits)
                    except queue.Full:
                        try:    self.data_q.get_nowait()
                        except queue.Empty: pass
                        self.data_q.put_nowait(bits)

                    self.status_q.put(("capture", self.capture_count))

            except serial.SerialException as e:
                self.status_q.put(("err", str(e)))
                break

        if self.ser and self.ser.is_open:
            self.ser.close()

    def stop(self):
        self.running = False


# =============================================================================
# MAIN VIEWER
# =============================================================================
class LogicAnalyzerViewer:

    def __init__(self, port):
        self.port         = port
        self.data_q       = queue.Queue(maxsize=8)
        self.status_q     = queue.Queue()
        self.paused       = False

        # Sample rate state
        self._sample_rate = RATE_OPTIONS[0][1]
        self._rate_label  = RATE_OPTIONS[0][0]
        self._rate_cmd    = RATE_OPTIONS[0][2]

        # Trigger state
        self._trig_ch     = 0
        self._trig_edge   = 0   # 0=rising, 1=falling

        self.waveform = np.zeros((DEPTH, NUM_CH), dtype=np.uint8)
        self._build_time_axis()
        self._build_ui()

        self.reader = SerialReader(port, self.data_q, self.status_q)
        self.reader.start()

    # ── time axis ─────────────────────────────────────────────────────────────
    def _build_time_axis(self):
        period_us            = 1e6 / self._sample_rate
        self.xs              = np.arange(DEPTH) * period_us
        self.total_window_us = DEPTH * period_us

    def _window_label(self):
        us = self.total_window_us
        if   us >= 1_000_000_000: return f"{us/1e9:.2f} ks"
        elif us >= 1_000_000:     return f"{us/1e6:.3f} s"
        elif us >= 1_000:         return f"{us/1e3:.3f} ms"
        else:                     return f"{us:.4f} us"

    # ── UI build ──────────────────────────────────────────────────────────────
    def _build_ui(self):
        matplotlib.rcParams.update({
            "figure.facecolor" : "#1E1E2E",
            "axes.facecolor"   : "#181825",
            "axes.edgecolor"   : "#45475A",
            "axes.labelcolor"  : "#CDD6F4",
            "xtick.color"      : "#6C7086",
            "ytick.color"      : "#1E1E2E",
            "grid.color"       : "#313244",
            "grid.linestyle"   : "--",
            "grid.linewidth"   : 0.5,
            "text.color"       : "#CDD6F4",
            "font.family"      : "monospace",
        })

        self.fig = plt.figure(figsize=(19, 10), facecolor="#1E1E2E")
        self.fig.canvas.manager.set_window_title(
            "FPGA Logic Analyzer  |  Nexys A7-100T"
        )
        self.fig.suptitle(
            f"FPGA Logic Analyzer   Nexys A7-100T   {DEPTH} samples / capture",
            fontsize=13, fontweight="bold", color="#CDD6F4", y=0.98,
        )

        # Waveform grid: 8 channels + status bar
        gs = self.fig.add_gridspec(
            NUM_CH + 1, 1,
            height_ratios=[1] * NUM_CH + [0.3],
            hspace=0.06,
            top=0.94, bottom=0.13, left=0.13, right=0.97,
        )

        # ── Waveform axes ──────────────────────────────────────────────────
        self.axes  = []
        self.lines = []
        for ch in range(NUM_CH):
            ax = self.fig.add_subplot(gs[ch])
            ax.set_zorder(1)
            ax.set_xlim(self.xs[0], self.xs[-1])
            ax.set_ylim(-0.3, 1.6)
            ax.set_yticks([])
            ax.grid(True, axis="x")
            for sp in ["top", "right", "left"]:
                ax.spines[sp].set_visible(False)
            lbl = CHANNEL_NAMES[ch] + (" (Trig)" if ch == self._trig_ch else "")
            ax.set_ylabel(
                lbl,
                fontsize=8, rotation=0, labelpad=90,
                va="center", color=COLORS[ch], fontweight="bold",
            )
            ln, = ax.step(
                self.xs, self.waveform[:, ch],
                where="post", color=COLORS[ch],
                linewidth=1.3, antialiased=True,
            )
            self.axes.append(ax)
            self.lines.append(ln)
            if ch == NUM_CH - 1:
                ax.set_xlabel("Time (us)", fontsize=9, color="#6C7086")
            else:
                ax.set_xticklabels([])

        # ── Status bar ─────────────────────────────────────────────────────
        ca = self.fig.add_subplot(gs[NUM_CH])
        ca.set_axis_off()
        self.status_text = ca.text(
            0.01, 0.5, f"Connecting to {self.port}...",
            transform=ca.transAxes,
            fontsize=9, color="#A6E3A1", va="center",
        )
        self.counter_text = ca.text(
            0.35, 0.5, "Captures: 0",
            transform=ca.transAxes,
            fontsize=9, color="#89B4FA", va="center",
        )
        self.rate_text = ca.text(
            0.54, 0.5,
            f"Rate: {self._rate_label.strip()}  |  Window: {self._window_label()}",
            transform=ca.transAxes,
            fontsize=9, color="#FAB387", va="center",
        )
        self.trig_text = ca.text(
            0.82, 0.5,
            f"Trig: CH{self._trig_ch}  Rising",
            transform=ca.transAxes,
            fontsize=9, color="#F38BA8", va="center",
        )

        # ── Dropdown: Sample Rate ──────────────────────────────────────────
        self.dd_rate = DropdownWidget(
            fig        = self.fig,
            rect       = [0.013, 0.030, 0.095, 0.030],
            options    = [r[0] for r in RATE_OPTIONS],
            on_select  = self._on_rate_change,
            init_index = 0,
            label_text = "Sample Rate",
        )

        # ── Dropdown: Trigger Channel ──────────────────────────────────────
        self.dd_trig_ch = DropdownWidget(
            fig        = self.fig,
            rect       = [0.120, 0.030, 0.090, 0.030],
            options    = TRIG_CH_OPTIONS,
            on_select  = self._on_trig_ch_change,
            init_index = 0,
            label_text = "Trig Channel",
        )

        # ── Dropdown: Trigger Edge ─────────────────────────────────────────
        self.dd_trig_edge = DropdownWidget(
            fig        = self.fig,
            rect       = [0.222, 0.030, 0.090, 0.030],
            options    = [e[0] for e in TRIG_EDGE_OPTIONS],
            on_select  = self._on_trig_edge_change,
            init_index = 0,
            label_text = "Trig Edge",
        )

        # ── Control buttons ────────────────────────────────────────────────
        # Four buttons spaced evenly in the right portion of the toolbar.
        # Reconnect button added to allow re-establishing a dropped USB
        # connection without restarting the application.
        b1 = self.fig.add_axes([0.66, 0.030, 0.073, 0.036])
        self.btn_pause = Button(b1, "|| Pause", color="#313244", hovercolor="#45475A")
        self.btn_pause.label.set_color("#CDD6F4")
        self.btn_pause.label.set_fontsize(8.5)
        self.btn_pause.on_clicked(self._toggle_pause)

        b2 = self.fig.add_axes([0.74, 0.030, 0.073, 0.036])
        self.btn_clear = Button(b2, "X Clear", color="#313244", hovercolor="#45475A")
        self.btn_clear.label.set_color("#CDD6F4")
        self.btn_clear.label.set_fontsize(8.5)
        self.btn_clear.on_clicked(self._clear)

        b3 = self.fig.add_axes([0.82, 0.030, 0.073, 0.036])
        self.btn_save = Button(b3, "S Save", color="#313244", hovercolor="#45475A")
        self.btn_save.label.set_color("#CDD6F4")
        self.btn_save.label.set_fontsize(8.5)
        self.btn_save.on_clicked(self._save)

        b4 = self.fig.add_axes([0.90, 0.030, 0.073, 0.036])
        self.btn_reconnect = Button(b4, "R Reconnect", color="#313244", hovercolor="#45475A")
        self.btn_reconnect.label.set_color("#FAB387")
        self.btn_reconnect.label.set_fontsize(8.0)
        self.btn_reconnect.on_clicked(self._reconnect)

        # ── Channel legend ─────────────────────────────────────────────────
        self.fig.legend(
            handles=[
                mpatches.Patch(color=COLORS[i], label=CHANNEL_NAMES[i])
                for i in range(NUM_CH)
            ],
            loc="upper right", ncol=4, fontsize=7.5,
            facecolor="#313244", edgecolor="#45475A", labelcolor="#CDD6F4",
            bbox_to_anchor=(0.97, 0.97),
        )

    # ── callbacks ─────────────────────────────────────────────────────────────

    def _on_rate_change(self, label, index):
        name, hz, cmd = RATE_OPTIONS[index]
        self._sample_rate = hz
        self._rate_label  = name
        self._rate_cmd    = cmd
        self.reader.send_rate(cmd)
        self._build_time_axis()
        for ax in self.axes:
            ax.set_xlim(self.xs[0], self.xs[-1])
        for ln in self.lines:
            ln.set_xdata(self.xs)
        self.rate_text.set_text(
            f"Rate: {name.strip()}  |  Window: {self._window_label()}"
        )
        self.waveform[:] = 0
        for ch, ln in enumerate(self.lines):
            ln.set_ydata(self.waveform[:, ch])
        self.fig.canvas.draw_idle()
        print(f"  [GUI] Rate  ->  {name.strip():<8}  "
              f"window = {self._window_label():<12}  cmd = 0x{cmd:02X}")

    def _update_trig_labels(self):
        for ch, ax in enumerate(self.axes):
            lbl = CHANNEL_NAMES[ch] + (" (Trig)" if ch == self._trig_ch else "")
            ax.set_ylabel(
                lbl,
                fontsize=8, rotation=0, labelpad=90,
                va="center", color=COLORS[ch], fontweight="bold",
            )

    def _on_trig_ch_change(self, label, index):
        self._trig_ch = index
        self.reader.send_trigger(self._trig_ch, self._trig_edge)
        edge_name = "Rising" if self._trig_edge == 0 else "Falling"
        self.trig_text.set_text(f"Trig: CH{index}  {edge_name}")
        self._update_trig_labels()
        self.fig.canvas.draw_idle()
        print(f"  [GUI] Trigger -> CH{index}, {edge_name}, "
              f"cmd = 0x{make_trigger_byte(index, self._trig_edge):02X}")

    def _on_trig_edge_change(self, label, index):
        self._trig_edge = TRIG_EDGE_OPTIONS[index][1]
        self.reader.send_trigger(self._trig_ch, self._trig_edge)
        edge_name = TRIG_EDGE_OPTIONS[index][0].strip()
        self.trig_text.set_text(f"Trig: CH{self._trig_ch}  {edge_name}")
        self.fig.canvas.draw_idle()
        print(f"  [GUI] Trigger -> CH{self._trig_ch}, {edge_name}, "
              f"cmd = 0x{make_trigger_byte(self._trig_ch, self._trig_edge):02X}")

    def _toggle_pause(self, _):
        self.paused = not self.paused
        self.btn_pause.label.set_text("> Resume" if self.paused else "|| Pause")
        self.fig.canvas.draw_idle()

    def _clear(self, _):
        self.waveform[:] = 0
        for ch, ln in enumerate(self.lines):
            ln.set_ydata(self.waveform[:, ch])
        self.fig.canvas.draw_idle()

    def _save(self, _):
        rate_str = self._rate_label.strip().replace(" ", "_")
        edge_str = "rise" if self._trig_edge == 0 else "fall"
        fname    = f"capture_{rate_str}_CH{self._trig_ch}_{edge_str}.png"
        self.fig.savefig(fname, dpi=150, facecolor=self.fig.get_facecolor())
        print(f"  [SAVE] -> {fname}")
        self.status_text.set_text(f"Saved: {fname}")
        self.status_text.set_color("#A6E3A1")
        self.fig.canvas.draw_idle()

    def _reconnect(self, _):
        """
        Stop the current serial reader thread and start a fresh one on the
        same port.  Call this after a USB disconnect/reconnect without
        restarting the application.

        The join() has a 2-second timeout matching the serial read timeout so
        the thread has a chance to unblock from ser.read() before we proceed.
        Queues are drained so the new thread starts with a clean state.
        """
        print(f"  [GUI] Reconnecting to {self.port}...")
        self.status_text.set_text(f"Reconnecting to {self.port}...")
        self.status_text.set_color("#FAB387")
        self.fig.canvas.draw_idle()

        # Signal the running thread to stop and wait for it to exit.
        self.reader.stop()
        self.reader.join(timeout=2.5)   # > 2.0 s serial timeout

        # Drain both queues so stale data/messages don't appear in the new
        # session.
        for q in (self.data_q, self.status_q):
            while not q.empty():
                try:    q.get_nowait()
                except queue.Empty: break

        # Spawn a new reader on the same port with the same queues.
        self.reader = SerialReader(self.port, self.data_q, self.status_q)
        self.reader.start()
        print(f"  [GUI] Reader thread restarted.")

    # ── animation update ──────────────────────────────────────────────────────
    def _update(self, _frame):
        while not self.status_q.empty():
            try:
                kind, val = self.status_q.get_nowait()
                if kind == "ok":
                    self.status_text.set_text(f"Connected | {val}")
                    self.status_text.set_color("#A6E3A1")
                elif kind == "err":
                    self.status_text.set_text(f"ERR: {val}  —  press Reconnect")
                    self.status_text.set_color("#F38BA8")
                elif kind == "capture":
                    self.counter_text.set_text(f"Captures: {val:,}")
                elif kind == "sync":
                    self.status_text.set_text(f"Resynced (discarded {val}B)")
                    self.status_text.set_color("#FAB387")
            except queue.Empty:
                break

        if not self.paused:
            latest = None
            while not self.data_q.empty():
                try:    latest = self.data_q.get_nowait()
                except queue.Empty: break
            if latest is not None:
                self.waveform = latest
                for ch, ln in enumerate(self.lines):
                    ln.set_ydata(self.waveform[:, ch])

        # blit=False is used (see FuncAnimation call below), so we do not
        # need to return a specific artist list — returning an empty tuple
        # satisfies matplotlib's protocol without any side effects.
        return ()

    def run(self):
        # blit=False is intentional.
        #
        # With blit=True, matplotlib caches a background snapshot after the
        # first frame and only redraws the artists returned by _update().
        # The DropdownWidget uses fig.canvas.draw_idle() to show/hide its
        # ax_list overlay, which invalidates the cached background.  On the
        # next animation tick, matplotlib restores the OLD snapshot (which may
        # include a now-closed dropdown) and draws the artist list on top,
        # producing a 0-100 ms visual flicker on every dropdown interaction.
        #
        # At a 100 ms refresh interval, blit=True provides negligible
        # performance benefit, so the simpler and flicker-free blit=False is
        # the correct choice here.
        self.anim = FuncAnimation(
            self.fig, self._update,
            interval=100, blit=False, cache_frame_data=False,
        )
        plt.show()
        self.reader.stop()


# =============================================================================
# ENTRY POINT
# =============================================================================
def main():
    port = sys.argv[1] if len(sys.argv) > 1 else (find_nexys_port() or "COM14")

    print()
    print("  +====================================================+")
    print("  |       FPGA Logic Analyzer  --  Nexys A7-100T      |")
    print("  +====================================================+")
    print(f"  |  Port      : {port:<38}|")
    print(f"  |  Baud      : {BAUD_RATE:<38,}|")
    print(f"  |  Depth     : {DEPTH:<38,}|")
    print(f"  |  Channels  : {NUM_CH:<38}|")
    print(f"  |  Rates     : 100 MHz -> 1 Hz  (18 steps)         |")
    print(f"  |  Trig CH   : CH0 - CH7  (dropdown)               |")
    print(f"  |  Trig Edge : Rising / Falling  (dropdown)         |")
    print(f"  |  Protocol  : single byte  0x01-0x2F              |")
    print("  +====================================================+")
    print()

    LogicAnalyzerViewer(port).run()


if __name__ == "__main__":
    main()
